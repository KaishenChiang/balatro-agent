return {
	descriptions = {
		Other = {
			load_success = {
				text = {
					"모드가 {C:green}성공적으로{}",
					"로드 됐습니다!",
				},
			},
			load_failure_d = {
				text = {
					"{C:attention}선행 모드{}가 없습니다!",
					"#1#",
				},
			},
			load_failure_c = {
				text = {
					"{C:attention}모드 충돌!",
					"#1#",
				},
			},
			load_failure_d_c = {
				text = {
					"{C:attention}선행 모드{}가 없습니다!",
					"#1#",
					"{C:attention}모드 충돌!",
					"#2#",
				},
			},
			load_failure_o = {
				text = {
					"{C:attention}버전이 너무 낮습니다!{}",
					"Steamodded{ C:money}0.9.8{}이하의 버전은",
					"더 이상 지원되지 않습니다.",
				},
			},
			load_failure_i = {
				text = {
					"{C:attention}호환 오류!{}",
					"Steamodded 버전 #1#을 요구하지만,",
					"설치된 버전은 #2#입니다.",
				},
			},
			load_failure_p = {
				text = {
					"{C:attention}프리픽스 충돌!{}",
					"이 모드의 프리픽스가",
					"다른 모드의 프리픽스와 같습니다",
					"({C:attention}#1#{})",
				},
			},
			load_failure_m = {
				text = {
					"{C:attention}메인 파일이 없습니다!{}",
					"이 모드의 메인 파일을",
					"찾을 수 없습니다.",
					"({C:attention}#1#{})",
				},
			},
			load_disabled = {
				text = {
					"이 모드는",
					"{C:attention}비활성화{} 됐습니다!",
				},
			},

			-- card perma bonuses
			card_extra_chips = {
				text = {
					"추가 칩 {C:chips}#1#{}개",
				},
			},
			card_x_chips = {
				text = {
					"칩 {X:chips,C:white}X#1#{}개",
				},
			},
			card_extra_x_chips = {
				text = {
					"추가 칩 {X:chips,C:white}X#1#{}개",
				},
			},
			card_extra_mult = {
				text = {
					"{C:mult}#1#{} 추가 배수",
				},
			},
			card_x_mult = {
				text = {
					"{X:mult,C:white}X#1#{} 배수",
				},
			},
			card_extra_x_mult = {
				text = {
					"{X:mult,C:white}X#1#{} 추가 배수",
				},
			},
			card_extra_p_dollars = {
				text = {
					"득점 시 {C:money}#1#{}",
				},
			},
			card_extra_h_chips = {
				text = {
					"손패에 남을 경우 칩 {C:chips}#1#{}개",
				},
			},
			card_h_x_chips = {
				text = {
					"손패에 남을 경우 칩 {X:chips,C:white}X#1#{}개",
				},
			},
			card_extra_h_x_chips = {
				text = {
					"손패에 남을 경우 추가 칩 {X:chips,C:white}X#1#{}개",
				},
			},
			card_extra_h_mult = {
				text = {
					"손패에 남을 경우 {C:mult}#1#{} 배수",
				},
			},
			card_h_x_mult = {
				text = {
					"손패에 남을 경우 {X:mult,C:white}X#1#{} 배수",
				},
			},
			card_extra_h_x_mult = {
				text = {
					"손패에 남을 경우 {X:mult,C:white}X#1#{} 추가 배수",
				},
			},
			card_extra_h_dollars = {
				text = {
					"라운드 종료 시 손패에 남아 있으면 {C:money}#1#{}",
				},
			},
			card_extra_repetitions = {
				text = {
					"이 카드를 {C:attention}#1#{}#2#",
					"다시 발동합니다",
				},
			},
			card_score = {
				text = {
					"점수 {C:purple}#1#{}",
				},
			},
			card_h_score = {
				text = {
					"손패에 남을 경우 점수 {C:purple}#1#{}",
				},
			},
			card_x_score = {
				text = {
					"점수 {X:purple,C:white}X#1#{}",
				},
			},
			card_h_x_score = {
				text = {
					"손패에 남을 경우 점수 {X:purple,C:white}X#1#{}",
				},
			},
			card_extra_score = {
				text = {
					"추가 점수 {C:purple}#1#{}",
				},
			},
			card_extra_h_score = {
				text = {
					"손패에 남을 경우 추가 점수 {C:purple}#1#{}",
				},
			},
			card_extra_x_score = {
				text = {
					"추가 점수 {X:purple,C:white}X#1#{}",
				},
			},
			card_extra_h_x_score = {
				text = {
					"손패에 남을 경우 추가 점수 {X:purple,C:white}X#1#{}",
				},
			},
			card_blind_size = {
				text = {
					"요구 점수 {C:blind}#1#{}",
				},
			},
			card_h_blind_size = {
				text = {
					"손패에 남을 경우 요구 점수 {C:blind}#1#{}",
				},
			},
			card_x_blind_size = {
				text = {
					"요구 점수 {X:blind,C:white}X#1#{}",
				},
			},
			card_h_x_blind_size = {
				text = {
					"손패에 남을 경우 요구 점수 {X:blind,C:white}X#1#{}",
				},
			},
			card_extra_blind_size = {
				text = {
					"추가 요구 점수 {C:blind}#1#{}",
				},
			},
			card_extra_h_blind_size = {
				text = {
					"손패에 남을 경우 추가 요구 점수 {C:blind}#1#{}",
				},
			},
			card_extra_x_blind_size = {
				text = {
					"추가 요구 점수 {X:blind,C:white}X#1#{}",
				},
			},
			card_extra_h_x_blind_size = {
				text = {
					"손패에 남을 경우 추가 요구 점수 {X:blind,C:white}X#1#{}",
				},
			},
			artist = {
				text = {
					"{C:inactive}아티스트",
				},
			},
			artist_credit = {
				name = "아티스트",
				text = {
					"{E:1}#1#{}",
				},
			},
			generic_card_limit = {
				name = "카드 제한",
				text = {
					"슬롯 {C:dark_edition}#1#{}개",
				},
			},
			generic_card_limit_plural = {
				name = "카드 제한",
				text = {
					"슬롯 {C:dark_edition}#1#{}개",
				},
			},
			generic_card_limit_pc = {
				name = "손패 크기",
				text = {
					"손패 크기 {C:dark_edition}#1#{}장",
				},
			},
			generic_card_limit_pc_plural = {
				name = "손패 크기",
				text = {
					"손패 크기 {C:dark_edition}#1#{}장",
				},
			},
			generic_extra_slots = {
				name = "슬롯 사용",
				text = {
					"슬롯 {C:dark_edition}#1#{}개를 차지",
				},
			},
			generic_extra_slots_pc = {
				name = "손패 공간",
				text = {
					"손패 {C:dark_edition}#1#{}장을 차지",
				},
			},
			card_chips_minus = {
				text = {
					"칩 {C:chips}#1#{}개",
				},
			},
		},
		Edition = {
			e_negative_playing_card = {
				name = "네거티브",
				text = {
					"손패 크기 {C:dark_edition}#1#{}장",
				},
			},
			e_negative_generic = {
				name = "네거티브",
				text = {
					"슬롯 {C:dark_edition}#1#{}개",
				},
			},
		},
		Enhanced = {
			m_gold = {
				name = "황금 카드",
				text = {
					"라운드 종료 시",
					"이 카드가 손패에 남아 있으면",
					"{C:money}#1#{}를 획득합니다",
				},
			},
			m_stone = {
				name = "석재 카드",
				text = {
					"칩 {C:chips}#1#{}개",
					"랭크 또는 문양이 없습니다",
				},
			},
			m_mult = {
				name = "배수 카드",
				text = {
					"{C:mult}#1#{} 배수",
				},
			},
			m_lucky = {
				name = "행운 카드",
				text = {
					"{C:green}#1#/#3#{} 확률로",
					"{C:mult}+#2#{} 배수를 획득합니다",
					"{C:green}#6#/#5#{} 확률로",
					"{C:money}$#4#{}를 획득합니다",
				},
			},
		},
	},
	misc = {
		achievement_names = {
			hidden_achievement = "???",
		},
		achievement_descriptions = {
			hidden_achievement = "미발견",
		},
		dictionary = {
			b_mods = "모드",
			b_mods_cap = "모드",
			b_modded_version = "모드된 버전!",
			b_steamodded = "Steamodded",
			b_credits = "크레딧",
			b_open_mods_dir = "모드 폴더 열기",
			b_no_mods = "아무런 모드도 찾지 못했습니다...",
			b_mod_list = "활성화된 모드들",
			b_mod_loader = "모드 로더",
			b_developed_by = "개발: ",
			b_rewrite_by = "재개발: ",
			b_github_project = "Github 프로젝트",
			b_github_bugs_1 = "버그를 제보하거나",
			b_github_bugs_2 = "코드에 기여할 수 있습니다",
			b_disable_mod_badges = "모드 배지 숨기기",
			b_vanilla_run_select = "바닐라 런 선택 메뉴",
			b_vanilla_run_select_info = "이 설정은 모드가 선택 메뉴에 페이지를 추가하면 무시됩니다",
			b_run_select_reduce = "런 선택 메뉴 최적화",
			b_run_select_reduce_info = "카드 수 감소 및 애니메이션 생략",
			b_author = "제작자",
			b_authors = "제작자",
			b_unknown = "불명",
			b_lovely_mod = "(Lovely 모드)",
			b_by = "By: ",
			b_priority = "우선도: ",
			b_config = "설정",
			b_additions = "추가 요소",
			b_stickers = "스티커",
			b_achievements = "업적",
			b_applies_stakes_1 = "적용: ",
			b_applies_stakes_2 = "",
			b_graphics_mipmap_level = "밉맵 레벨",
			b_browse = "열기",
			b_search_prompt = "모드 검색",
			b_search_button = "검색",
			b_seeded_unlocks = "시드런 언락",
			b_seeded_unlocks_info = "시드런에서도 해금과 발견이 가능합니다",
			ml_achievement_settings = {
				"비활성화",
				"활성화",
				"제한 무시",
			},
			b_deckskins_lc = "저대비 색상",
			b_deckskins_hc = "고대비 색상",
			b_deckskins_def = "기본 색상",
			b_limit = "최대 ",
			b_retrigger_single = "번",
			b_retrigger_plural = "번",
			k_enhanced = "강화",
			run_select_locked_stake = "잠김",
			run_select_locked_stake_message = "이 덱으로 다음 스테이크에서 먼저 승리하세요: ",
			run_select_locked_stake_and = ", ",
			run_select_nothing = "없음",
			run_select_selected = "선택됨",
			run_select_quick_start = "빠른 시작",
			run_select_play = "플레이",
			run_setup_enable_seed = "시드 활성화",
			run_select_deck_choice = "덱 선택",
			run_select_stake_choice = "스테이크 선택",
			run_select_deck_choice_random = "랜덤 덱",
			run_select_stake_choice_random = "랜덤 스테이크",
		},
		v_dictionary = {
			c_types = "#1# 종류",
			cashout_hidden = "...그리고 #1#개 더",
			a_xchips = "칩 X#1# 개",
			a_xchips_minus = "칩 -X#1# 개",
			a_score = "점수 #1#",
			a_xscore = "점수 X#1#",
			a_xscore_minus = "점수 -X#1#",
			a_blind_size = "요구 점수 #1#",
			a_xblind_size = "요구 점수 X#1#",
			a_xblind_size_minus = "요구 점수 -X#1#",
			smods_version_mismatch = {
				"이 런을 시작한 후 Steamodded의",
				"버전이 바뀌었습니다!",
				"계속 진행 할 경우 예상치 않은",
				"오류가 발생할 수 있습니다.",
				"시작한 버전: #1#",
				"현재 버전: #2#",
			},
		},
	},
}
